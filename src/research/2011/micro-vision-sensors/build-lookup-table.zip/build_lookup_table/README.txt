This directory has a matlab file called createlookuptable

This code evaluates a range of design parameters and creates a lookup table for the physically realizable instances of the design.

To use this code:

a) Open testarray_general and testarray_lensless

b) Find the places where the parameter variables and their step sizes are defined. Change this to what you want.

c) Run createlookuptable. This may take a while.

mymats.mat is a mat file that contains a mapping between refractive indices between 0 and 1 and their densities.

Questions? Email me at sjkoppal {AT} seas.harvard.edu