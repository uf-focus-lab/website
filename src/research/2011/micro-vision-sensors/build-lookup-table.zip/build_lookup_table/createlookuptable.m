clear all;
close all;

% The target solid angle
realomega = pi/15.15;

% running the code that evaluates a set of possible designs for all cases except
% lensless
testarray_general

% save the data
save lookuptable_1.mat lookuptable_1;

clear all; 
close all;

% The target solid angle
omega = pi/15.15;

% running the code that evaluates the set of possible designs for the
% lensless case
testarray_lensless

save lookuptable_2.mat lookuptable_2;

clear all;
close all;

% Visualizing the tables is up to you.

% Some equations that might help: 

% Volume of the cuboid     
%     v = 2*t(end)*t(end-1)*t(3);
%     
% Spherical cap equations
%     d = t(4)/2;
%     R = t(5);
%     h = sqrt(R^2 - d^2);
% Volume spherical cap
%     vcap = (1/6)*(3.14)*(h)*((3*d*d) + h^2);
%     
%     n = t(1);
%     n2 = t(2);
%     
%     s1 = abs(mat - n);
%     s1 = find(s1 == min(s1(:)));
%     
%     s2 = abs(mat - n2);
%     s2 = find(s2 == min(s2(:)));
%     
%     matdensities is in mymats.mat in the folder
% Spherical cap weight
%     w = ((v - vcap)*matdensities(s1(1)) + vcap*matdensities(s2(1)));