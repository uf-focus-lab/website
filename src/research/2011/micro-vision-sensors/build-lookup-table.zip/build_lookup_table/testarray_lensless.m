% clear;
% close all;

lookuptable_2 = zeros(20000,5);

% number of samples required
numsamp = 100;

% viewing directions
thetas = [0:pi/(2*numsamp):pi/2];

% steps in the angle
dtheta = 90/numsamp;

% count variable
mytmpcount = 1;

% steps for the variables (see paper for variable names)
ustep = 0.1;
nstep = 0.1;

% loops for the template height
for u = 0.1:ustep:10
% for u = 1
    
    u

% loops for the index of refraction for the refractive slab
for n2 = 1:nstep:2
% for n2 = 2
    
%     templatesize = 0.1;

% pixel pitch
step = 0.0052;

% max cost
maxcost = omega/5;

if maxcost == omega
    input('omega cannot equal maxcost');
end

% load tmp

% max step
% maxstep = 100;

count = 1;
ds = [];

% loop over the viewing direction
for th = 2:length(thetas)
    
%     th/length(thetas)
    
    realtheta = thetas(th);
    
    theta = (pi/2) - asin((sin((pi/2) - realtheta))/(n2));
    
    x = u/tan(theta);

    % obtain d
    dcount1 = 1;
    dcount2 = 1;
    clear score1 score2;
    
%     for d = 0.01:0.01:75
% %     for td = 1:length(nds)
% %         d = nds(td,1);
%        
%         t1 = (abs(((n2*d)/(2)) - n2*x))/(sqrt(u^2 + (1 - n2*n2)*((d/2) - x)^2));
%         t2 = (abs(((n2*d)/(2)) + n2*x))/(sqrt(u^2 + (1 - n2*n2)*((d/2) + x)^2));
%         
%         tmp = (tan(omega) - ((t2 - t1)/(1 + t1*t2)));
%         if isreal(tmp)
%             score1(dcount1,1) = abs(tan(omega) - ((t2 - t1)/(1 + t1*t2)));
%             score1(dcount1,2) = d;
%             dcount1 = dcount1 + 1;
%         end
%         
%         tmp = (tan(omega) - ((t2 + t1)/(1 - t1*t2)));
%         if isreal(tmp)
%             score2(dcount2,1) = abs(tan(omega) - ((t2 + t1)/(1 - t1*t2)));
%             score2(dcount2,2) = d;
%             dcount2 = dcount2 + 1;
%         end
%         
%     end

    oval = 4;
    valstep = 1;

    if th < 3 | isempty(ds)
        bigval = 15;
    else
        if ds(size(ds,1),1) > oval
            tmp = ds(size(ds,1),1);
        else
            tmp = oval;
             valstep = 0.01;
        end
        bigval = tmp;
    end
    
    jstep = 3;
    jumpsize = bigval/jstep;
    decsize = 1.3;

    startval = 0.01;
    finval = bigval;
    flag = 1;
    
    while valstep > 0.0001 & flag
        
         dcount1 = 1;
         clear score1;
       
         for d = startval:valstep:finval
             
            t1 = (abs(((n2*d)/(2)) - n2*x))/(sqrt(u^2 + (1 - n2*n2)*((d/2) - x)^2));
            t2 = (abs(((n2*d)/(2)) + n2*x))/(sqrt(u^2 + (1 - n2*n2)*((d/2) + x)^2));
            
            s1 = asin(sin(atan(t1)));
            s2 = asin(sin(atan(t2)));
            
            s1a = asin((1/n2)*sin(atan(t1)));
            s2b = asin((1/n2)*sin(atan(t2)));
            
            tmps = abs((s2 - s1) - omega);
            
            c1 = acos(cos(atan(t1)));
            c2 = acos(cos(atan(t2)));
            
            tmpnc = abs((c2 - c1) - omega);
            
            a = (d/2 - x)/(sin(atan(t1))/n2);
            
            b = (d/2 + x)/(sin(atan(t2))/n2);
            
            tmpc = acos((a^2 + b^2 - d^2)/(2*abs(a*b)));
            
%             tmp2 = pi - (tmpa + tmpb + tmpc);
        
            tmp = (tan(omega) - ((t2 - t1)/(1 + t1*t2)));
            
%             isreal(tmp)
%             tmpc < pi/2
%             tmps < 0.1
%             tmpnc < 0.1
%             abs(tmpc - (s2b - s1a)) < 0.1
%             input('wait')
            
            if isreal(tmp) & tmpc < pi/2 & tmps < 0.1 & tmpnc < 0.1 & abs(tmpc - (s2b - s1a)) < 0.1
                score1(dcount1,1) = abs(tan(omega) - ((t2 - t1)/(1 + t1*t2)));
                score1(dcount1,2) = d;
                dcount1 = dcount1 + 1;
            end
            
         end
         
         if dcount1 == 1
             flag = 0;
         else
             s = score1(:,1);
             f = find(s == min(s(:)));
             tmp = score1(f(1),2);
             
             startval = tmp - jumpsize*valstep;
             if startval < 2
                 startval = 0.01;
             end
             
             tmp = tmp + jumpsize*valstep;
             
             if tmp > finval
                 % do nothing
             else
                 finval = tmp;
             end
             
             valstep = valstep/(decsize);
         end        
         
    end
    
    if th < 3 | isempty(ds)
        bigval = 15;
    else
        if ds(size(ds,1),1) > oval
            tmp = ds(size(ds,1),1);
        else
            tmp = oval;
        end
        bigval = tmp;
    end
    
    jumpsize = bigval/jstep;
    startval = 0.01;
    
    valstep = 0.1;
    
    if bigval == oval
        valstep = 0.001;
    else
        valstep = 1;
    end
    
    finval = bigval;
    flag = 1;
    
    while valstep > 0.0001 & flag 
        
         dcount2 = 1;
         clear score2;
       
         for d = startval:valstep:finval
             
            t1 = (abs(((n2*d)/(2)) - n2*x))/(sqrt(u^2 + (1 - n2*n2)*((d/2) - x)^2));
            t2 = (abs(((n2*d)/(2)) + n2*x))/(sqrt(u^2 + (1 - n2*n2)*((d/2) + x)^2));
            
            a = (d/2 - x)/(sin(atan(t1))/n2);
            
            b = (d/2 + x)/(sin(atan(t2))/n2);
            
            s1 = asin(sin(atan(t1)));
            s2 = asin(sin(atan(t2)));
            
            s1a = asin((1/n2)*sin(atan(t1)));
            s2b = asin((1/n2)*sin(atan(t2)));
            
            tmps = abs((s2 + s1) - omega);
            
            c1 = acos(cos(atan(t1)));
            c2 = acos(cos(atan(t2)));
            
            tmpnc = abs((c2 + c1) - omega);
            
            tmpc = acos((a^2 + b^2 - d^2)/(2*abs(a*b)));
        
            tmp = (tan(omega) - ((t2 + t1)/(1 - t1*t2)));
            
            if isreal(tmp) & tmps < 0.1 & tmpnc < 0.1 & abs(tmpc - (s2b + s1a)) < 0.1
                score2(dcount2,1) = abs(tan(omega) - ((t2 + t1)/(1 - t1*t2)));
                score2(dcount2,2) = d;
                dcount2 = dcount2 + 1;
            end
            
         end
         
%              if th == 91
%         input('wait')
%     end
    
         
         if dcount2 == 1
             flag = 0;
         else
             s = score2(:,1);
             f = find(s == min(s(:)));
             tmp = score2(f(1),2);
             
             startval = tmp - jumpsize*valstep;
             if startval < 2
%                  startval = 0.01;
             end
             
             if min(s(:)) < 0.005
                 flag = 0;
             else
             
                 tmp = tmp + jumpsize*valstep;

                 if tmp > finval
                     % do nothing
                 else
                     finval = tmp;
                 end

                 valstep = valstep/(decsize);
             end
         end        
         
    end
    
    
%     figure
%     hold;
    
    if dcount1 > 1 & dcount2 == 1
        score = score1(:,1);
%                 plot(score1(:,1))
        score(find(score == 0)) = inf;
        f = find(score == min(score(:)));
        tmp = score1(f(1),:);
        ds(count,:) = [tmp(2) x th 1];
        count = count + 1;

    elseif dcount1 == 1 & dcount2 > 1
        score = score2(:,1);
%                     plot(score2(:,1),'r')
        score(find(score == 0)) = inf;
        f = find(score == min(score(:)));
        tmp = score2(f(1),:);
        ds(count,:) = [tmp(2) x th 2];
        count = count + 1;

    elseif dcount1 > 1 & dcount2 > 1
        
%                     plot(score2(:,1),'r')
%                        plot(score1(:,1))
        
            if min(score1(:,1)) < min(score2(:,1))
            score = score1(:,1);
            score(find(score == 0)) = inf;
            f = find(score == min(score(:)));
            tmp = score1(f(1),:);
            ds(count,:) = [tmp(2) x th 1];
            count = count + 1;
 
        else
            score = score2(:,1);
            score(find(score == 0)) = inf;
            f = find(score == min(score(:)));
            tmp = score2(f(1),:);
            ds(count,:) = [tmp(2) x th 2];
            count = count + 1;
                
            end

    else
        % do nothing
    end
    
%     ds(count-1,1)
%     input('wait')
%     close all
%     
end

clear t1 t2 t1_p t2_p

% input('wait');

% now calculate how much play is there in each lens
  
for i = 1:count-1
    
%     i/(count-1)
    
    cost = 0;
    
    d = ds(i,1);
    x = ds(i,2);
    
    t1 = atan((abs((d/2)-x))/u);
    t1_p = asin(n2*sin(t1));
    
    t2 = atan((abs((d/2)+x))/u);
    t2_p = asin(n2*sin(t2));
    
    if isreal(t1_p) & isreal(t2_p)
       
        if ds(i,end) == 1
           newomega = t2_p - t1_p;
        else
           newomega = t2_p + t1_p;
        end
        
    else
        
        input('help');
        
    end
    
    if abs(newomega - omega) > 0.1
        input('wait')
    end

    tcost = 1;
    clear costsr;
    right = x;
    
    % while cost < maxcost && right < maxstep
    while cost < maxcost 
       right = right + step;
       
       t1 = atan((abs((d/2)-right))/u);
       t1_p = abs(asin(n2*sin(t1)));
    
       t2 = atan((abs((d/2)+right))/u);
       t2_p = abs(asin(n2*sin(t2)));
       
       a = sqrt(u^2 + (right + (d/2))^2);
       b = sqrt(u^2 + (right - (d/2))^2);
     
       op = acos((a^2 + b^2 - d^2)/(2*a*b));
    
        if isreal(t1_p) & isreal(t2_p)

%             if t2_p >= 0 & t1_p >= 0 
            if abs(abs(t2 - t1) - op) < 0.01
               newomega = t2_p - t1_p;
            else
               newomega = t2_p + t1_p;
            end

    else
        
        input('help');
        
        end
       
       cost = abs(newomega - omega);
       costsr(tcost) = cost;
       tcost = tcost + 1;
       
       if cost > maxcost
            right = right - step;
       end
       
    end
    
    cost = 0;
    clear costsl;
    tcost = 1;
    left = x;
    % do the negative
%     while cost < maxcost && abs(left) < maxstep
    while cost < maxcost
       left = left - step;
       
       t1 = atan((abs((d/2)-abs(left)))/u);
       t1_p = abs(asin(n2*sin(t1)));
    
       t2 = atan((abs((d/2)+abs(left)))/u);
       t2_p = abs(asin(n2*sin(t2)));
       
       a = sqrt(u^2 + (abs(left) + (d/2))^2);
       b = sqrt(u^2 + (abs(left) - (d/2))^2);
     
       op = acos((a^2 + b^2 - d^2)/(2*a*b));
    
    if isreal(t1_p) & isreal(t2_p)
       
%         if t2_p >= 0 & t1_p >= 0 
        if abs(abs(t2 - t1) - op) < 0.01
           newomega = t2_p - t1_p;
        else
           newomega = t2_p + t1_p;
        end

    else
        
        input('help');
        
    end
        
       
       cost = abs(newomega - omega);
       costsl(tcost) = cost;
       tcost = tcost + 1;
       
       if cost > maxcost
            left = left + step;
       end
       
    end
    
%     if (left <= 0 && right <= 0) | (left > 0 & right > 0)
%         ang = abs(atand(abs(right)/u) - atand(abs(left)/u));
%         leftang = atand(abs(left)/u);
%         rightang = atand(abs(right)/u);
%         base = abs(abs(left) - abs(right));
%         
%         % angles for the links
%         leftext = atand(abs((abs(left) + d/2)/u));
%         lside = u*secd(leftext);    
%         rightext = atand(abs((abs(right) - d/2)/u));
%         rside = u*secd(rightext);
%         
%     else
%         ang = atand((right)/u) + atand(abs(left)/u);
%         leftang = -1*atand(abs(left)/u);
%         rightang = atand((right)/u);
%         base = abs(abs(left) + abs(right));
%         
%         % angles for the links
%         leftext = atand(abs((abs(left) - d/2)/u));
%         lside = u*secd(leftext);
%         rightext = atand(abs((abs(right) - d/2)/u));
%         rside = u*secd(rightext);
%         
%     end

    if (left <= 0 && right <= 0) | (left > 0 & right > 0)
        
        tmp1 = n2*sind(atand(abs(left)/u));
        tmp2 = n2*sind(atand(abs(right)/u));

        leftang = asind(tmp1);      
        rightang = asind(tmp2);        
        ang = abs(rightang) - abs(leftang);
        
%         leftang = atand(abs(left)/u);
%         rightang = atand(abs(right)/u);
        
        base = abs(abs(left) - abs(right));
        
        % angles for the links
        leftext = atand(abs((abs(left) + d/2)/u));
        lside = u*secd(leftext);    
        rightext = atand(abs((abs(right) - d/2)/u));
        rside = u*secd(rightext);
        
    else
        
        tmp1 = n2*sind(atand(abs(left)/u));
        tmp2 = n2*sind(atand(abs(right)/u));

        leftang = -1*asind(tmp1);      
        rightang = asind(tmp2);        
        ang = abs(rightang) + abs(leftang);
        
%         leftang = -1*atand(abs(left)/u);
%         rightang = atand((right)/u);
        
        base = abs(abs(left) + abs(right));
        
        % angles for the links
        leftext = atand(abs((abs(left) - d/2)/u));
        lside = u*secd(leftext);
        rightext = atand(abs((abs(right) - d/2)/u));
        rside = u*secd(rightext);
        
    end
    
    
    
    lensplay(i,:) = [(right - left) left right ang leftang rightang base leftext rightext lside rside];
    
end

% plot(thetas(ds(:,3))*180/pi,lensplay(:,4));
% hold
% plot(thetas(ds(:,3))*180/pi,dtheta*ones(size(1:size(lensplay,1))),'r')

% dt = abs(ds(:,1) - templatesize);
% f = find(dt == min(dt(:)));
%  ds(count,:) = [tmp(2) x th 2];
%     lensplay(i,:) = [(right - left) left right ang leftang rightang base
%     leftext rightext lside rside];

if exist('lensplay') == 1
    
    
    for f = 1:1:size(lensplay,1)

%         t1 = lensplay(:,4);
%         f = find(t1 == max(t1(:)));

        FOV = lensplay(f(1),4);

%         tmp = lensplay(:,4);
%         tmpf = find(tmp==max(tmp(:)));

        NumPixels = lensplay(f(1),1)/step;

        % lensplay(f(1),:)
        tmp = lensplay(f(1),:);
        
        
        lookuptable_2(mytmpcount,:) = [n2 u ds(f(1),1) FOV NumPixels];
        mytmpcount = mytmpcount + 1;
        
    end
    
end

% n2
% FOV
% NumPixels
% FOV/NumPixel

clear lensplay ds;

end



% input('wait');

% input('wait')
% close all;
clear lensplay ds;

end

